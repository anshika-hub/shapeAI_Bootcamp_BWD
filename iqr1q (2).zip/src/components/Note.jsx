import React from "react";

function Note() {
  return (
  <div className="note">
    <h1>Javascript and React.js</h1>
    <p>This was an amaging botcamp taken by Saurya sinha sir.we 
      covered everything from the scratch including Javascript ,
      React.js,Html.
      </p>
      </div>
        );
        }

        export default Note;
